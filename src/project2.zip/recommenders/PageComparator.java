package recommenders;

/**
 * Wilson Gip
 */
import java.util.Comparator;

public class PageComparator implements Comparator<PageNode> {
    @Override
    public int compare(PageNode lhs, PageNode rhs) {
        return (lhs.getPageRank() > rhs.getPageRank() ? -1 : lhs.getPageRank() < rhs.getPageRank() ? 1 : 0);
    }
}
